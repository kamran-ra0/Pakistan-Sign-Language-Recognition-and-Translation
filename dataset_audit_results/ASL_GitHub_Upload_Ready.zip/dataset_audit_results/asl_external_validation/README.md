# External validation: American Sign Language (ASL) alphabet recognition

This directory contains experimental outputs for four architectures (ConvNeXt, DeiT, EfficientNetV2-B3, MobileNetV4), four seeds (42, 123, 2026, 7777), and three evaluation protocols: combined stratified and two directional leave-one-dataset-out (LODO) evaluations. It is intended as an addition to the existing `dataset_audit_results` directory; existing PSL materials should remain unchanged.

## Datasets

- Dataset A: https://www.kaggle.com/datasets/dorukdemirci/asl-alphabet-dataset/data
- Dataset B: https://www.kaggle.com/datasets/pradiptomondal/aslalphabets/data
- Training notebook: https://www.kaggle.com/code/mrmuhammadkamran/external-asl-19-10

The work evaluates 24 ASL classes (J and Z excluded), with A→B and B→A LODO directions. The combined stratified and LODO splits differ in train/test data composition, so accuracy differences are descriptive cross-protocol comparisons, not causal estimates of domain shift alone.

## Contents

Each available run has some or all of `final_metrics.json`, `classification_report.csv`, `confusion_matrix.csv`, `per_class_metrics.csv`, `per_dataset_metrics.csv`, and `test_predictions.csv`. Existing archive file names with `(1)` suffix are preserved. The separately supplied ConvNeXt combined-stratified seed 7777 outputs have been included.

`summary_metrics.csv` aggregates ONLY runs with a provided `final_metrics` JSON (no invented records).

## Known gaps / cautions

- The original results archive does not include `final_metrics.json` for ConvNeXt combined-stratified seed 42, though its other evaluation CSVs are present. Checkpoint/run JSON can be added separately.
- Image-content duplicate checking was not performed according to the reported run metadata (`retain_all_no_content_duplicate_checks`). Do not describe stratified evaluations as content-duplicate-free.
- The source Kaggle datasets are linked, not redistributed, to respect dataset licensing and storage.
- `test_predictions` can include file paths; review them before making the repository public.
